import pyautogui

# rest of your code here...

pyautogui

python -c "import pyautogui; print(pyautogui.__file__)"


