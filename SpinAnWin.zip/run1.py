#
# (C)J~Net 2023
# jnet.sytes.net
#
# python -m ensurepip
# pip install pyautogui
# pip install Pillow
# python -m pip install Pillow
#
# ./run.py
#
#import pyautogui
from PIL import ImageGrab
import time
from PIL import Image
import time
import sys

print("Roulette Rebet Button Auto-Clicker")
print("Made By J~Net (c)2023 jnet.club")
print("")

# Add path to site-packages to sys.path
sys.path.append('C:\\Users\\pc\\AppData\\Local\\Programs\\Python\\Python311\\Lib\\site-packages')

import pyautogui
import time
import sys
import os
from PIL import ImageGrab

pyautogui.FAILSAFE=False

def capture_screenshot():
    screen_image=ImageGrab.grab(all_screens=True)
    file_path='screen.png'
    screen_image.save(file_path)
    return file_path


def compare_images(image1, image2):
    result=pyautogui.locateOnScreen(image1)
    
    if result is not None:
        return result
    
    pyautogui.keyUp('ctrl')
  #  pyautogui.press('tab')
    return None


def main():
    print("Running In 0 Seconds...")
    #time.sleep(1)

    while True:
        try:
            screen_image_path=capture_screenshot()
            result=compare_images("rebet.png", screen_image_path)
            if result:
                print("Found Button, Clicking Now...")
                pyautogui.click(result)
            time.sleep(1)
        except KeyboardInterrupt:
            sys.exit()

if __name__ == "__main__":
    # Set minSearchTime to a float value
    minSearchTime=1.0
    main()
